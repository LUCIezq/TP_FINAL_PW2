<?php

class ShowData
{
    public static function show($data)
    {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}
