<?php

class RequestState
{
    public const PENDIENTE = 1;
    public const RECHAZADA = 3;
    public const ACEPTADA = 2;
}