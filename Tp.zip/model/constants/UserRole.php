<?php

class UserRole
{
    public const JUGADOR = 1;
    public const ADMIN = 2;
    public const EDITOR = 3;
}